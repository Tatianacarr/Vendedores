public class Main {
    public static void main(String[] args){
        Vendedor vendedor= new Vendedor("Angui","Tecnologia",2596.25,96,9);
        vendedor.mostrar();

    }
}